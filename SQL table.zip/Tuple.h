#ifndef Tuple_h
#define Tuple_h

#include <stdio.h>
#include <vector>
#include <string>

class Tuple : public std::vector<std::string> {};

#endif /* Tuple_h */
